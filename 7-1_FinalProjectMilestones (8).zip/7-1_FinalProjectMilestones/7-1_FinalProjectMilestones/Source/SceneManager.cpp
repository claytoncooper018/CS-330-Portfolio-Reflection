///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// Manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Updated for CS-330 Milestone 5 by Clayton Cooper, 2026
//
//  Milestone 5 additions:
//    - DefineObjectMaterials() : wood, metal, ceramic, glass, paper, cement
//    - SetupSceneLights()      : directional key light + warm point light (lamp)
//                                + cool fill point light
//    - SetShaderMaterial()     : applies material uniforms before each draw call
//    - bUseLighting enabled
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// Global shader variable names
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  Constructor
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  Destructor
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = nullptr;
	delete m_basicMeshes;
	m_basicMeshes = nullptr;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  Loads an image file from disk and uploads it to the GPU
 *  as a 2D texture, then stores its ID and tag for later
 *  retrieval by SetShaderTexture().
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0, height = 0, channels = 0;
	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (!image)
	{
		std::cout << "Failed to load image: " << filename << std::endl;
		return false;
	}

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);

	// Repeat wrapping so tiled textures tile correctly
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	if (channels == 3)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
	else if (channels == 4)
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

	glGenerateMipmap(GL_TEXTURE_2D);
	stbi_image_free(image);
	glBindTexture(GL_TEXTURE_2D, 0);

	// Store the texture ID and its tag in the slot array
	m_textureIDs[m_loadedTextures].ID = textureID;
	m_textureIDs[m_loadedTextures].tag = tag;
	m_loadedTextures++;

	std::cout << "Loaded texture: " << filename << std::endl;
	return true;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  Activates each loaded texture on its corresponding
 *  texture unit so the fragment shader can sample them.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID() / FindTextureSlot()
 *
 *  Look up a texture by its string tag and return either
 *  the GPU texture ID or its slot index.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
			return m_textureIDs[i].ID;
	}
	return -1;
}

int SceneManager::FindTextureSlot(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
			return i;
	}
	return -1;
}

/***********************************************************
 *  FindMaterial()
 *
 *  Searches the material list for a material with the given
 *  tag. Returns true and fills 'material' if found.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	for (auto& mat : m_objectMaterials)
	{
		if (mat.tag == tag)
		{
			material = mat;
			return true;
		}
	}
	return false;
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  Binds the named texture to its slot and tells the shader
 *  to sample from the texture instead of the flat color.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (!m_pShaderManager) return;

	m_pShaderManager->setIntValue(g_UseTextureName, true);

	int slot = FindTextureSlot(textureTag);
	int texID = FindTextureID(textureTag);
	if (slot >= 0 && texID >= 0)
	{
		glActiveTexture(GL_TEXTURE0 + slot);
		glBindTexture(GL_TEXTURE_2D, texID);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Passes a flat RGBA color to the shader and disables
 *  texture sampling for this draw call.
 ***********************************************************/
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
	if (!m_pShaderManager) return;

	glm::vec4 color(r, g, b, a);
	m_pShaderManager->setIntValue(g_UseTextureName, false);
	m_pShaderManager->setVec4Value(g_ColorValueName, color);
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Scales the texture coordinates so a texture can tile
 *  across a large surface (e.g., the ground plane).
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (!m_pShaderManager) return;
	m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Looks up the named material and uploads its diffuse
 *  color, specular color, and shininess to the fragment
 *  shader so the Phong lighting calculations are accurate.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (!m_pShaderManager) return;

	OBJECT_MATERIAL mat;
	if (FindMaterial(materialTag, mat))
	{
		m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
	}
}

/***********************************************************
 *  SetTransformations()
 *
 *  Builds the model matrix from scale, rotation (XYZ
 *  Euler), translation, and an optional offset, then
 *  uploads it to the vertex shader's "model" uniform.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float Xrot, float Yrot, float Zrot,
	glm::vec3 positionXYZ,
	glm::vec3 offset)
{
	glm::mat4 model =
		glm::translate(positionXYZ + offset) *
		glm::rotate(glm::radians(Zrot), glm::vec3(0.0f, 0.0f, 1.0f)) *
		glm::rotate(glm::radians(Yrot), glm::vec3(0.0f, 1.0f, 0.0f)) *
		glm::rotate(glm::radians(Xrot), glm::vec3(1.0f, 0.0f, 0.0f)) *
		glm::scale(scaleXYZ);

	if (m_pShaderManager)
		m_pShaderManager->setMat4Value(g_ModelName, model);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Configures the physical material properties for every
 *  object type in the scene. These values drive how the
 *  Phong lighting model reacts to each light source.
 *
 *  Materials defined:
 *    "wood"    - warm, matte surface; low specular
 *    "metal"   - cool, moderately shiny; mid specular
 *    "ceramic" - smooth, slightly glossy; mid specular
 *    "glass"   - very smooth and shiny; high specular
 *    "paper"   - flat, almost no specular
 *    "cement"  - rough and dull; near-zero specular
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// --- Wood (desk surface, books spine) ---
	// Warm amber diffuse; very low specular; near-zero shininess
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.55f, 0.35f, 0.15f);
	woodMaterial.specularColor = glm::vec3(0.10f, 0.08f, 0.05f);
	woodMaterial.shininess = 4.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// --- Metal (lamp base, stand, joint) ---
	// Neutral grey diffuse; higher specular; noticeable shininess
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.40f, 0.40f, 0.42f);
	metalMaterial.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
	metalMaterial.shininess = 64.0f;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	// --- Ceramic (coffee mug body) ---
	// Off-white diffuse; moderate specular; medium shininess
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.diffuseColor = glm::vec3(0.50f, 0.45f, 0.40f);
	ceramicMaterial.specularColor = glm::vec3(0.50f, 0.50f, 0.50f);
	ceramicMaterial.shininess = 32.0f;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	// --- Glass (lamp bulb) ---
	// Bright diffuse; very high specular; very shiny
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.90f, 0.90f, 0.80f);
	glassMaterial.specularColor = glm::vec3(1.00f, 1.00f, 0.95f);
	glassMaterial.shininess = 128.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	// --- Paper / book cover ---
	// Warm white diffuse; near-zero specular; flat appearance
	OBJECT_MATERIAL paperMaterial;
	paperMaterial.diffuseColor = glm::vec3(0.80f, 0.70f, 0.55f);
	paperMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	paperMaterial.shininess = 2.0f;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);

	// --- Cement / floor ---
	// Medium grey diffuse; slight specular; rough surface
	OBJECT_MATERIAL cementMaterial;
	cementMaterial.diffuseColor = glm::vec3(0.30f, 0.30f, 0.30f); // darker grey so floor doesn't wash out
	cementMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	cementMaterial.shininess = 4.0f;
	cementMaterial.tag = "cement";
	m_objectMaterials.push_back(cementMaterial);

	// --- Red fabric (lampshade) ---
	// Warm red diffuse; low specular; matte cloth look
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.diffuseColor = glm::vec3(0.70f, 0.10f, 0.10f);
	fabricMaterial.specularColor = glm::vec3(0.05f, 0.02f, 0.02f);
	fabricMaterial.shininess = 2.0f;
	fabricMaterial.tag = "fabric";
	m_objectMaterials.push_back(fabricMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures all active light sources for the desk scene:
 *
 *  Light 0 - Directional (overhead daylight)
 *    Simulates cool ambient daylight coming from above and
 *    slightly behind the camera. Low ambient, moderate
 *    diffuse, no specular — fills the whole scene evenly.
 *
 *  Light 1 - Point light (warm desk lamp)
 *    Positioned at the lamp bulb. Warm yellow-orange color
 *    with moderate diffuse and strong specular to simulate
 *    the glossy highlight a real incandescent bulb casts.
 *
 *  Light 2 - Point light (cool fill light)
 *    Positioned opposite the lamp at low height to ensure
 *    no object falls into complete shadow. Cool blue-white
 *    tint; low intensity; no specular contribution.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// -------------------------------------------------------
	// Light 0: Directional — deep red atmospheric fill
	// Very dim dark red ambient gives the whole scene a moody
	// crimson tint. Minimal diffuse so objects stay dark
	// except where the spotlight hits them.
	// -------------------------------------------------------
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);
	m_pShaderManager->setVec3Value("directionalLight.direction", 0.0f, -1.0f, 0.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.40f, 0.05f, 0.05f); // brighter red glow — objects visible
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.20f, 0.03f, 0.03f); // soft red diffuse on surfaces
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.00f, 0.00f, 0.00f); // no specular from ambient

	// -------------------------------------------------------
	// Light 1: Spot light — focused white beam on the table
	// Positioned directly above the desk center, pointing
	// straight down. Bright white diffuse + strong specular
	// creates a clear pool of light on the table and objects.
	// Wider cone angle so more of the table is illuminated.
	// -------------------------------------------------------
	m_pShaderManager->setBoolValue("spotLight.bActive", true);
	m_pShaderManager->setVec3Value("spotLight.position", 0.0f, 6.0f, 0.5f);  // high above table center
	m_pShaderManager->setVec3Value("spotLight.direction", 0.0f, -1.0f, 0.0f);  // pointing straight down
	m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(25.0f))); // wider inner cone
	m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(38.0f))); // wider soft falloff edge
	m_pShaderManager->setVec3Value("spotLight.ambient", 0.10f, 0.02f, 0.02f); // slight red tint at beam edge
	m_pShaderManager->setVec3Value("spotLight.diffuse", 1.20f, 1.10f, 1.00f); // extra bright beam — lights whole table
	m_pShaderManager->setVec3Value("spotLight.specular", 1.00f, 1.00f, 0.95f); // strong specular on lit surfaces
	m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);
	m_pShaderManager->setFloatValue("spotLight.linear", 0.04f);  // less falloff = brighter at distance
	m_pShaderManager->setFloatValue("spotLight.quadratic", 0.008f);

	// Deactivate all point lights — scene uses spot + directional only
	m_pShaderManager->setBoolValue("pointLights[0].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[2].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[3].bActive", false);
	m_pShaderManager->setBoolValue("pointLights[4].bActive", false);

	// Enable the Phong lighting path in the fragment shader
	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  Loads all mesh shapes, textures, object materials, and
 *  scene lights into memory before rendering begins.
 *  Order matters: materials and lights must be set before
 *  the first RenderScene() call.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load basic mesh geometry into GPU buffers
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();

	// Load scene textures 
	CreateGLTexture("textures/desk_wood.jpg", "deskWood");
	CreateGLTexture("textures/lamp_metal.jpg", "lampMetal");
	CreateGLTexture("textures/mug_ceramic.jpg", "mugCeramic");
	CreateGLTexture("textures/book_cover.jpg", "bookCover");

	// Upload all textures to their GPU slots
	BindGLTextures();

	// Define Phong material properties for each object type
	DefineObjectMaterials();

	// Configure and activate scene light sources
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  Draws every object in the 3D desk scene. For each mesh:
 *    1. Set scale, rotation, and position via SetTransformations()
 *    2. Set texture (SetShaderTexture) OR flat color (SetShaderColor)
 *    3. Set material via SetShaderMaterial() for correct Phong response
 *    4. Call the appropriate Draw function
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Shared transform variables reused across all draw calls
	glm::vec3 scaleXYZ;
	float Xrot = 0.0f, Yrot = 0.0f, Zrot = 0.0f;
	glm::vec3 posXYZ;

	// Helper lambda: uses texture if loaded, falls back to a solid color
	auto safeSetTexture = [this](const std::string& tag,
		glm::vec4 fallbackColor = glm::vec4(1.0f, 0.0f, 0.0f, 1.0f))
		{
			if (FindTextureSlot(tag) >= 0)
				SetShaderTexture(tag);
			else
				SetShaderColor(fallbackColor.r, fallbackColor.g, fallbackColor.b, fallbackColor.a);
		};

	// Reset UV scale to 1:1 unless overridden per object
	SetTextureUVScale(1.0f, 1.0f);

	// ==========================================================
	// GROUND PLANE
	// Large flat floor; cement material reflects a little light
	// ==========================================================
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	posXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0, 0, 0, posXYZ);
	SetTextureUVScale(4.0f, 4.0f);           // tile the floor texture 4x
	SetShaderColor(0.75f, 0.75f, 0.75f, 1.0f);
	SetShaderMaterial("cement");             // cement: rough, low specular
	m_basicMeshes->DrawPlaneMesh();
	SetTextureUVScale(1.0f, 1.0f);           // reset UV scale

	// ==========================================================
	// DESK SURFACE
	// A wide flat plane elevated just above the floor plane.
	// Wood material: warm diffuse, very little specular.
	// ==========================================================
	SetTransformations(glm::vec3(6.0f, 0.1f, 4.0f), 0, 0, 0,
		glm::vec3(0.0f, 0.1f, 0.0f));
	safeSetTexture("deskWood");
	SetShaderMaterial("wood");              // wood: warm, matte
	m_basicMeshes->DrawPlaneMesh();

	// ==========================================================
	// COFFEE MUG — body (cylinder) + handle (torus)
	// Ceramic material: smooth, moderate specular highlight
	// ==========================================================

	// Mug body
	SetTransformations(glm::vec3(0.30f, 0.50f, 0.30f), 0, 0, 0,
		glm::vec3(-1.0f, 0.25f, 1.0f));
	safeSetTexture("mugCeramic");
	SetShaderMaterial("ceramic");           // ceramic: glossy, mid shininess
	m_basicMeshes->DrawCylinderMesh();

	// Mug handle (torus rotated 90° around Y to face outward)
	SetTransformations(glm::vec3(0.15f, 0.15f, 0.15f), 0, 90, 0,
		glm::vec3(-0.70f, 0.30f, 1.0f));
	safeSetTexture("mugCeramic");
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTorusMesh();

	// ==========================================================
	// DESK LAMP — base, stand, joint, shade, bulb
	// Metal and glass materials for realistic light interaction.
	// The lamp point light (Light 1) is positioned at the bulb.
	// ==========================================================

	// Lamp base — wide flat cylinder; dark metal
	SetTransformations(glm::vec3(0.60f, 0.08f, 0.60f), 0, 0, 0,
		glm::vec3(1.5f, 0.08f, -1.0f));
	SetShaderColor(0.20f, 0.20f, 0.20f, 1.0f);
	SetShaderMaterial("metal");             // metal: high specular, shiny
	m_basicMeshes->DrawCylinderMesh();

	// Lamp stand — thin tall cylinder; light grey metal
	SetTransformations(glm::vec3(0.05f, 0.70f, 0.05f), 0, 0, 0,
		glm::vec3(1.5f, 0.45f, -1.0f));
	SetShaderColor(0.70f, 0.70f, 0.70f, 1.0f);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Lamp joint — small sphere where stand meets shade
	SetTransformations(glm::vec3(0.08f, 0.08f, 0.08f), 0, 0, 0,
		glm::vec3(1.5f, 0.80f, -1.0f));
	SetShaderColor(0.30f, 0.30f, 0.30f, 1.0f);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawSphereMesh();

	// Lampshade — cone; red fabric material (matte, warm)
	SetTransformations(glm::vec3(0.35f, 0.70f, 0.35f), 0, 0, 0,
		glm::vec3(1.5f, 1.30f, -1.0f));
	SetShaderColor(0.80f, 0.10f, 0.10f, 1.0f);
	SetShaderMaterial("fabric");            // fabric: dull red, no specular
	m_basicMeshes->DrawConeMesh();

	// Lamp bulb — small sphere; glass material (very shiny)
	// This sphere sits at the exact position of pointLights[0]
	SetTransformations(glm::vec3(0.12f, 0.12f, 0.12f), 0, 0, 0,
		glm::vec3(1.5f, 1.40f, -1.0f));
	SetShaderColor(1.00f, 1.00f, 0.80f, 1.0f);
	SetShaderMaterial("glass");             // glass: strong specular highlight
	m_basicMeshes->DrawSphereMesh();

	// ==========================================================
	// STACKED BOOKS — three box shapes, slightly offset in Y
	// Paper/book-cover material: warm, flat, near-zero specular
	// ==========================================================
	for (int i = 0; i < 3; i++)
	{
		SetTransformations(glm::vec3(0.60f, 0.10f, 0.40f), 0, 0, 0,
			glm::vec3(0.8f, 0.05f + i * 0.10f, 1.0f));
		safeSetTexture("bookCover");
		SetShaderMaterial("paper");         // paper: matte, absorbs light
		m_basicMeshes->DrawBoxMesh();
	}
}

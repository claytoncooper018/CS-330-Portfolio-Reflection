///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// Manage preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Updated by Clayton Cooper - Fixed texture loading issues
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>
#include <glm/glm.hpp>

class SceneManager
{
public:
    // Constructor
    SceneManager(ShaderManager* pShaderManager);
    // Destructor
    ~SceneManager();

    // Texture information
    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    // Material information
    struct OBJECT_MATERIAL
    {
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

private:
    ShaderManager* m_pShaderManager;     // Pointer to shader manager
    ShapeMeshes* m_basicMeshes;          // Pointer to shape meshes
    int m_loadedTextures;                // Number of loaded textures
    TEXTURE_INFO m_textureIDs[16];       // Texture slots (up to 16)
    std::vector<OBJECT_MATERIAL> m_objectMaterials; // Material list

    // Texture loading and management
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();
    int FindTextureID(std::string tag);
    int FindTextureSlot(std::string tag);

    // Material lookup
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // Transformations
    void SetTransformations(glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ,
        glm::vec3 offset = glm::vec3(0.0f));

    // Shader helpers
    void SetShaderColor(float red, float green, float blue, float alpha);
    void SetShaderTexture(std::string textureTag);
    void SetTextureUVScale(float u, float v);
    void SetShaderMaterial(std::string materialTag);

    // Scene setup helpers (declared so SceneManager.cpp definitions match)
    void DefineObjectMaterials();
    void SetupSceneLights();

public:
    // Student-customizable methods
    void PrepareScene();
    void RenderScene();
};
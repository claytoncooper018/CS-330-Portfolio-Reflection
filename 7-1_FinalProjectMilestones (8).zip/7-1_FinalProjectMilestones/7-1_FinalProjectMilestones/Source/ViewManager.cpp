///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// --------------------------------------------------------------------------
// Global variables and settings
// --------------------------------------------------------------------------
namespace
{
    const int WINDOW_WIDTH = 1000;   // Initial window width
    const int WINDOW_HEIGHT = 800;   // Initial window height

    const char* g_ViewName = "view";           // Shader variable for view matrix
    const char* g_ProjectionName = "projection"; // Shader variable for projection matrix

    Camera* g_pCamera = nullptr;  // Global camera pointer

    // Mouse movement tracking
    float gLastX = WINDOW_WIDTH / 2.0f; // Last X position of mouse
    float gLastY = WINDOW_HEIGHT / 2.0f; // Last Y position of mouse
    bool gFirstMouse = true;            // True when mouse moves for the first time

    // Frame timing for smooth camera movement
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Projection mode: false = perspective, true = orthographic
    bool bOrthographicProjection = false;

    // Cursor visibility control
    bool bCursorDisabled = true;

    // Track TAB key press for toggling cursor
    bool bTabPressed = false;
}

// --------------------------------------------------------------------------
// Constructor
// --------------------------------------------------------------------------
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;  // Store shader manager
    m_pWindow = NULL;

    // Create and initialize camera object
    g_pCamera = new Camera();

    // Set default camera position, direction, and properties
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80;            // Camera field of view
    g_pCamera->MovementSpeed = 20;   // Default WASD movement speed
}

// --------------------------------------------------------------------------
// Destructor
// --------------------------------------------------------------------------
ViewManager::~ViewManager()
{
    m_pShaderManager = NULL;
    m_pWindow = NULL;

    // Free allocated memory for the camera
    if (g_pCamera != nullptr)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

// --------------------------------------------------------------------------
// Create the main OpenGL display window
// --------------------------------------------------------------------------
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = nullptr;

    // Attempt to create GLFW window
    window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }
    glfwMakeContextCurrent(window);

    // Capture mouse input by default (disable cursor)
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Set mouse movement and scroll callbacks
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
    glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

    // Enable alpha blending for transparency
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;

    return window;
}

// --------------------------------------------------------------------------
// Mouse movement callback
// Automatically called by GLFW whenever the mouse moves
// --------------------------------------------------------------------------
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    // Record the first mouse movement to prevent jumps
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    // Calculate movement offsets
    float xOffset = static_cast<float>(xMousePos) - gLastX;
    float yOffset = gLastY - static_cast<float>(yMousePos); // Reversed Y-axis

    // Update last mouse positions
    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    // Update camera orientation based on mouse movement
    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

// --------------------------------------------------------------------------
// Mouse scroll callback
// Adjusts camera movement speed dynamically
// --------------------------------------------------------------------------
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
    if (g_pCamera)
    {
        g_pCamera->MovementSpeed += static_cast<float>(yOffset) * 5.0f; // Scroll changes speed
        if (g_pCamera->MovementSpeed < 1.0f) g_pCamera->MovementSpeed = 1.0f;   // Clamp min speed
        if (g_pCamera->MovementSpeed > 100.0f) g_pCamera->MovementSpeed = 100.0f; // Clamp max speed
    }
}

// --------------------------------------------------------------------------
// Keyboard input processing
// Handles WASD, QE, TAB, ESC, and projection toggles
// --------------------------------------------------------------------------
void ViewManager::ProcessKeyboardEvents()
{
    // Update frame timing for smooth movement
    float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // Close window if ESC is pressed
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);

    // Toggle cursor visibility with TAB
    if (glfwGetKey(m_pWindow, GLFW_KEY_TAB) == GLFW_PRESS)
        bTabPressed = true;
    if (bTabPressed && glfwGetKey(m_pWindow, GLFW_KEY_TAB) == GLFW_RELEASE)
    {
        bTabPressed = false;
        if (bCursorDisabled)
            glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        else
            glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

        bCursorDisabled = !bCursorDisabled; // Flip cursor state
    }

    // WASD movement (horizontal plane)
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS) g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS) g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS) g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS) g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

    // QE keys for vertical movement (up/down)
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS) g_pCamera->ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS) g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

    // Toggle between perspective and orthographic views
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS) bOrthographicProjection = false;
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS) bOrthographicProjection = true;
}

// --------------------------------------------------------------------------
// Prepare the scene view before rendering each frame
// Sets view and projection matrices in the shader
// --------------------------------------------------------------------------
void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    // Handle keyboard input before rendering
    ProcessKeyboardEvents();

    // Retrieve the current view matrix from the camera
    view = g_pCamera->GetViewMatrix();

    // Set projection matrix based on mode
    if (!bOrthographicProjection)
    {
        // Perspective projection
        projection = glm::perspective(glm::radians(g_pCamera->Zoom),
            (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
            0.1f, 100.0f);
    }
    else
    {
        // Orthographic projection (top-down view)
        projection = glm::ortho(-20.0f, 20.0f, -20.0f, 20.0f, 0.1f, 100.0f);
    }

    // Send matrices and camera position to shader
    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}